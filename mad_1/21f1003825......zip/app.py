import csv
import os
import matplotlib.pyplot as plt 
import matplotlib
matplotlib.use('Agg')
from flask import Flask, render_template, request

app = Flask(__name__)

class InvalidInput(Exception):
    pass

@app.route("/",methods=["GET","POST"])
def get_form_data():
    if request.method == "GET":
        return render_template("index.html")
    elif request.method == "POST":
        try:
            requested_data = request.form['ID']

            if requested_data == "student_id":
                data,total = get_student_details(request.form['id_value'])
                return render_template("student.html.jinja2",student_data = data,total=total)

            elif requested_data == "course_id":
                avg,max_,marks = get_course_details(int(request.form['id_value']))
                generate_image(marks)
                return render_template("course.html.jinja2",average_marks=avg,maximum_marks=max_)

        except InvalidInput:
            return render_template("error.html")


def get_student_details(student_id) -> list:
    details = []
    with open("data.csv","r") as f:
        reader = csv.reader(f)
        next(reader,None)
        for row in reader:
            if row[0] == student_id:
                details.append(row)

    if len(details) == 0:
        raise InvalidInput

    return details,sum(int(mark) for _,_,mark in details)

def get_course_details(course_id):
    marks = []
    with open("data.csv","r") as f:
        reader = csv.reader(f)
        next(reader,None)
        for row in reader:
            if int(row[1]) == course_id:
                marks.append(int(row[2]))

    if len(marks) == 0:
        raise InvalidInput

    return sum(marks)/len(marks),max(marks),marks
    
def generate_image(marks):
    plt.clf()
    plt.hist(marks,bins=8)
    #plt.xticks(marks,[i for i in range(20,101,10)])
    plt.xlabel("Marks")
    plt.ylabel("Frequency")
    plt.savefig('static/fig_out.jpg')

if __name__ == '__main__':
    app.run()

